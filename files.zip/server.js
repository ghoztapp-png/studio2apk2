/**
 * AAB Forge — Backend Build Server
 * 
 * Stack: Node.js + Express
 * Requires: Java 17+, Android SDK command-line tools (sdkmanager, gradle)
 * 
 * Install deps:
 *   npm install express multer uuid archiver cors
 * 
 * Set env vars (or use a .env file with dotenv):
 *   ANDROID_SDK_ROOT=/path/to/android-sdk
 *   BUILD_DIR=/tmp/aab-forge-builds   (optional, defaults to /tmp/aab-forge-builds)
 *   PORT=3001
 */

const express = require('express');
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { exec, spawn } = require('child_process');
const { promisify } = require('util');
const { v4: uuidv4 } = require('uuid');
const archiver = require('archiver');
const cors = require('cors');

const execAsync = promisify(exec);
const app = express();

app.use(cors());
app.use(express.json());

// ── Config ──────────────────────────────────────────────────────────────────
const BUILD_DIR   = process.env.BUILD_DIR || '/tmp/aab-forge-builds';
const SDK_ROOT    = process.env.ANDROID_SDK_ROOT || '/opt/android-sdk';
const PORT        = process.env.PORT || 3001;
const MAX_ZIP_MB  = 200;

fs.mkdirSync(BUILD_DIR, { recursive: true });

// ── In-memory job store (replace with Redis/Postgres for production) ─────────
const jobs = new Map(); // jobId → { status, progress, stage, log, aabPath, keystorePath }

function getJob(id) { return jobs.get(id); }
function setJob(id, data) { jobs.set(id, { ...(jobs.get(id) || {}), ...data }); }

function log(jobId, text, type = '') {
  const job = getJob(jobId);
  if (!job) return;
  job.log = job.log || [];
  job.log.push({ text, type });
  console.log(`[${jobId.slice(0,8)}] ${text}`);
}

function progress(jobId, pct, stage) {
  setJob(jobId, { progress: pct, stage });
}

// ── Multer setup ──────────────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(BUILD_DIR, 'uploads');
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => cb(null, uuidv4() + '.zip'),
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_ZIP_MB * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.originalname.endsWith('.zip')) return cb(new Error('Only .zip files are accepted'));
    cb(null, true);
  },
});

// ── Routes ────────────────────────────────────────────────────────────────────

// POST /api/build — receive ZIP + config, queue a build
app.post('/api/build', upload.single('zip'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No ZIP file uploaded' });

  const {
    appName, appId, versionName, versionCode,
    minSdk, keyAlias, keystorePass, keyCn, keyCountry,
  } = req.body;

  // Basic validation
  if (!appName || !appId || !versionName || !versionCode) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  if (!/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/.test(appId)) {
    return res.status(400).json({ error: 'Invalid application ID format' });
  }
  if (!keystorePass || keystorePass.length < 6) {
    return res.status(400).json({ error: 'Keystore password too short' });
  }

  const jobId = uuidv4();
  setJob(jobId, {
    status: 'queued',
    progress: 0,
    stage: 'Queued',
    log: [],
    createdAt: Date.now(),
    config: { appName, appId, versionName, versionCode: parseInt(versionCode), minSdk: parseInt(minSdk) || 24, keyAlias, keystorePass, keyCn, keyCountry },
    zipPath: req.file.path,
  });

  // Kick off async build (don't await — respond immediately)
  runBuild(jobId).catch(err => {
    setJob(jobId, { status: 'error', error: err.message });
  });

  res.json({ jobId });
});

// GET /api/status/:id — poll build status
app.get('/api/status/:id', (req, res) => {
  const job = getJob(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });

  const response = {
    status:   job.status,
    progress: job.progress,
    stage:    job.stage,
    log:      job.log || [],
  };

  if (job.status === 'done') {
    response.jobId       = req.params.id;
    response.aabName     = job.aabName;
    response.keystoreName = job.keystoreName;
  }

  if (job.status === 'error') {
    response.error = job.error;
  }

  res.json(response);
});

// GET /api/download/:id/aab — download the built AAB
app.get('/api/download/:id/aab', (req, res) => {
  const job = getJob(req.params.id);
  if (!job || job.status !== 'done') return res.status(404).json({ error: 'Not ready' });
  if (!fs.existsSync(job.aabPath)) return res.status(404).json({ error: 'File not found' });
  res.download(job.aabPath, job.aabName || 'app-release.aab');
});

// GET /api/download/:id/keystore — download the generated keystore
app.get('/api/download/:id/keystore', (req, res) => {
  const job = getJob(req.params.id);
  if (!job || job.status !== 'done') return res.status(404).json({ error: 'Not ready' });
  if (!fs.existsSync(job.keystorePath)) return res.status(404).json({ error: 'File not found' });
  res.download(job.keystorePath, job.keystoreName || 'release.keystore');
});

// Serve frontend
app.use(express.static(path.join(__dirname, '../frontend')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, '../frontend/index.html')));

// ── Build Pipeline ────────────────────────────────────────────────────────────

async function runBuild(jobId) {
  const job   = getJob(jobId);
  const cfg   = job.config;
  const workDir = path.join(BUILD_DIR, jobId);

  try {
    fs.mkdirSync(workDir, { recursive: true });
    setJob(jobId, { status: 'building' });

    // ── Step 1: Unzip ─────────────────────────────────────────────────────
    progress(jobId, 5, 'Extracting ZIP');
    log(jobId, 'Extracting project ZIP...', 'warn');
    await extractZip(job.zipPath, workDir);
    log(jobId, 'Extraction complete', 'ok');

    // ── Step 2: Detect project root ───────────────────────────────────────
    progress(jobId, 10, 'Detecting project structure');
    const projectRoot = await detectProjectRoot(workDir);
    log(jobId, 'Project root: ' + path.relative(workDir, projectRoot), 'ok');

    // ── Step 3: Inject build config ───────────────────────────────────────
    progress(jobId, 20, 'Configuring build files');
    log(jobId, 'Patching build.gradle with your config...', 'warn');
    await patchBuildGradle(projectRoot, cfg);
    log(jobId, 'build.gradle patched', 'ok');

    await patchManifest(projectRoot, cfg);
    log(jobId, 'AndroidManifest.xml updated', 'ok');

    await ensureGradleWrapper(projectRoot);

    // ── Step 4: Generate keystore ─────────────────────────────────────────
    progress(jobId, 30, 'Generating signing keystore');
    log(jobId, 'Generating signing keystore...', 'warn');
    const keystorePath = path.join(workDir, 'release.keystore');
    await generateKeystore(keystorePath, cfg);
    log(jobId, 'Keystore generated', 'ok');

    // Write keystore properties for Gradle signing
    const keystorePropsPath = path.join(projectRoot, 'keystore.properties');
    fs.writeFileSync(keystorePropsPath,
      `storeFile=${keystorePath}\nstorePassword=${cfg.keystorePass}\nkeyAlias=${cfg.keyAlias}\nkeyPassword=${cfg.keystorePass}\n`
    );

    // Inject signing config into build.gradle
    await injectSigningConfig(projectRoot, keystorePropsPath, cfg);
    log(jobId, 'Signing config injected into build.gradle', 'ok');

    // ── Step 5: Gradle build ──────────────────────────────────────────────
    progress(jobId, 40, 'Running Gradle build');
    log(jobId, 'Starting Gradle build (this takes 2-5 mins)...', 'warn');

    await runGradle(projectRoot, jobId, (line) => {
      log(jobId, line);
    });

    log(jobId, 'Gradle build complete', 'ok');

    // ── Step 6: Find AAB output ───────────────────────────────────────────
    progress(jobId, 90, 'Locating AAB output');
    const aabPath = await findAAB(projectRoot);
    if (!aabPath) throw new Error('No .aab file found after build. Check your project structure.');
    log(jobId, 'AAB found: ' + path.basename(aabPath), 'ok');

    // Copy AAB to a predictable output location
    const outAab = path.join(workDir, `${cfg.appId}-${cfg.versionName}-release.aab`);
    fs.copyFileSync(aabPath, outAab);

    progress(jobId, 100, 'Done');
    log(jobId, '✓ Build successful!', 'ok');

    setJob(jobId, {
      status:       'done',
      aabPath:      outAab,
      aabName:      path.basename(outAab),
      keystorePath: keystorePath,
      keystoreName: `${cfg.appId}-release.keystore`,
    });

    // Clean up uploaded ZIP
    fs.rmSync(job.zipPath, { force: true });

  } catch (err) {
    log(jobId, 'BUILD FAILED: ' + err.message, 'err');
    setJob(jobId, { status: 'error', error: err.message });
    throw err;
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

async function extractZip(zipPath, destDir) {
  // Using unzip (available on most Linux systems)
  await execAsync(`unzip -o "${zipPath}" -d "${destDir}"`);
}

async function detectProjectRoot(workDir) {
  // Look for settings.gradle or build.gradle — could be at root or in a subdir
  const candidates = [
    workDir,
    ...fs.readdirSync(workDir).map(f => path.join(workDir, f)).filter(f => fs.statSync(f).isDirectory()),
  ];

  for (const dir of candidates) {
    const hasSettings = fs.existsSync(path.join(dir, 'settings.gradle')) || fs.existsSync(path.join(dir, 'settings.gradle.kts'));
    const hasGradle   = fs.existsSync(path.join(dir, 'build.gradle')) || fs.existsSync(path.join(dir, 'build.gradle.kts'));
    if (hasSettings || hasGradle) return dir;
  }

  throw new Error('Could not find build.gradle or settings.gradle in the ZIP. Make sure your project is at the root or one level deep.');
}

async function patchBuildGradle(projectRoot, cfg) {
  // Try to patch app/build.gradle
  const appBuildGradle = path.join(projectRoot, 'app', 'build.gradle');
  const appBuildGradleKts = path.join(projectRoot, 'app', 'build.gradle.kts');

  let gradlePath = null;
  let content = null;

  if (fs.existsSync(appBuildGradle)) {
    gradlePath = appBuildGradle;
    content = fs.readFileSync(gradlePath, 'utf8');
  } else if (fs.existsSync(appBuildGradleKts)) {
    gradlePath = appBuildGradleKts;
    content = fs.readFileSync(gradlePath, 'utf8');
  } else {
    // Single-module project — patch root build.gradle
    gradlePath = fs.existsSync(path.join(projectRoot, 'build.gradle'))
      ? path.join(projectRoot, 'build.gradle')
      : path.join(projectRoot, 'build.gradle.kts');
    content = fs.readFileSync(gradlePath, 'utf8');
  }

  // Patch applicationId
  content = content.replace(/applicationId\s+["'].*?["']/, `applicationId "${cfg.appId}"`);
  // Patch versionCode
  content = content.replace(/versionCode\s+\d+/, `versionCode ${cfg.versionCode}`);
  // Patch versionName
  content = content.replace(/versionName\s+["'].*?["']/, `versionName "${cfg.versionName}"`);
  // Patch minSdk
  content = content.replace(/minSdkVersion\s+\d+/, `minSdkVersion ${cfg.minSdk}`);
  content = content.replace(/minSdk\s+=?\s*\d+/, `minSdk ${cfg.minSdk}`);

  // If no applicationId line exists, inject defaultConfig block
  if (!content.includes('applicationId')) {
    const injection = `
    defaultConfig {
        applicationId "${cfg.appId}"
        minSdk ${cfg.minSdk}
        targetSdk 34
        versionCode ${cfg.versionCode}
        versionName "${cfg.versionName}"
    }`;
    content = content.replace(/android\s*\{/, `android {\n${injection}`);
  }

  fs.writeFileSync(gradlePath, content);
}

async function patchManifest(projectRoot, cfg) {
  const manifestPath = findFile(projectRoot, 'AndroidManifest.xml');
  if (!manifestPath) return; // not critical — might be in Kotlin DSL

  let content = fs.readFileSync(manifestPath, 'utf8');

  // Update package attribute if present
  content = content.replace(/package="[^"]*"/, `package="${cfg.appId}"`);

  // Update app label if app_name string is directly in manifest
  if (cfg.appName) {
    content = content.replace(/android:label="[^"]*"/, `android:label="${cfg.appName}"`);
  }

  fs.writeFileSync(manifestPath, content);
}

async function ensureGradleWrapper(projectRoot) {
  const gradlew = path.join(projectRoot, 'gradlew');
  if (!fs.existsSync(gradlew)) {
    // Create a minimal gradle wrapper if missing
    await execAsync(`cd "${projectRoot}" && gradle wrapper --gradle-version 8.4`, {
      env: { ...process.env, ANDROID_SDK_ROOT: SDK_ROOT },
    }).catch(() => {
      // gradle wrapper command might not be available — copy from system
      throw new Error('No gradlew found in project and could not generate one. Please include the Gradle wrapper (gradlew) in your ZIP.');
    });
  }
  // Make gradlew executable
  fs.chmodSync(gradlew, '755');
}

async function generateKeystore(keystorePath, cfg) {
  const dname = `CN=${cfg.keyCn || 'Unknown'}, OU=Mobile, O=${cfg.keyCn || 'Unknown'}, L=Unknown, S=Unknown, C=${cfg.keyCountry || 'US'}`;
  const cmd = [
    'keytool',
    '-genkeypair',
    '-v',
    `-keystore "${keystorePath}"`,
    `-alias "${cfg.keyAlias}"`,
    `-keyalg RSA`,
    `-keysize 2048`,
    `-validity 10000`,
    `-storepass "${cfg.keystorePass}"`,
    `-keypass "${cfg.keystorePass}"`,
    `-dname "${dname}"`,
  ].join(' ');

  await execAsync(cmd);
}

async function injectSigningConfig(projectRoot, keystorePropsPath, cfg) {
  const appBuildGradle = fs.existsSync(path.join(projectRoot, 'app', 'build.gradle'))
    ? path.join(projectRoot, 'app', 'build.gradle')
    : path.join(projectRoot, 'build.gradle');

  let content = fs.readFileSync(appBuildGradle, 'utf8');

  // Only inject if no signingConfigs block already
  if (content.includes('signingConfigs')) return;

  const signingBlock = `
    signingConfigs {
        release {
            def keystoreProps = new Properties()
            keystoreProps.load(new FileInputStream(rootProject.file("keystore.properties")))
            storeFile file(keystoreProps['storeFile'])
            storePassword keystoreProps['storePassword']
            keyAlias keystoreProps['keyAlias']
            keyPassword keystoreProps['keyPassword']
        }
    }
`;

  // Insert signingConfigs before buildTypes
  content = content.replace(/(buildTypes\s*\{)/, signingBlock + '\n    $1');

  // Add signingConfig to release buildType
  content = content.replace(
    /(release\s*\{[^}]*)(})/,
    `$1    signingConfig signingConfigs.release\n        $2`
  );

  fs.writeFileSync(appBuildGradle, content);

  // Copy keystore.properties to project root for Gradle to find
  fs.copyFileSync(keystorePropsPath, path.join(projectRoot, 'keystore.properties'));
}

function runGradle(projectRoot, jobId, onLine) {
  return new Promise((resolve, reject) => {
    const gradlew = path.join(projectRoot, 'gradlew');
    const env = {
      ...process.env,
      ANDROID_SDK_ROOT: SDK_ROOT,
      JAVA_OPTS: '-Xmx2g',
      GRADLE_OPTS: '-Dorg.gradle.daemon=false -Dorg.gradle.jvmargs=-Xmx2g',
    };

    const proc = spawn(gradlew, ['bundleRelease', '--no-daemon', '--stacktrace'], {
      cwd: projectRoot,
      env,
    });

    let stderr = '';

    proc.stdout.on('data', d => {
      const lines = d.toString().split('\n').filter(Boolean);
      lines.forEach(line => {
        onLine(line.trim());
        // Update progress based on Gradle task output
        if (line.includes(':compileRelease')) updateGradleProgress(jobId, 55, 'Compiling Java/Kotlin');
        if (line.includes(':processRelease')) updateGradleProgress(jobId, 65, 'Processing resources');
        if (line.includes(':packageRelease')) updateGradleProgress(jobId, 75, 'Packaging bundle');
        if (line.includes(':bundleRelease'))  updateGradleProgress(jobId, 85, 'Bundling AAB');
        if (line.includes('BUILD SUCCESSFUL')) updateGradleProgress(jobId, 90, 'Build successful');
      });
    });

    proc.stderr.on('data', d => { stderr += d.toString(); });

    proc.on('close', code => {
      if (code === 0) return resolve();
      reject(new Error('Gradle build failed (exit ' + code + '):\n' + stderr.slice(-2000)));
    });

    proc.on('error', err => reject(new Error('Could not run gradlew: ' + err.message)));
  });
}

function updateGradleProgress(jobId, pct, stage) {
  const job = getJob(jobId);
  if (job && job.progress < pct) progress(jobId, pct, stage);
}

async function findAAB(projectRoot) {
  // Common output paths
  const patterns = [
    path.join(projectRoot, 'app', 'build', 'outputs', 'bundle', 'release', '*.aab'),
    path.join(projectRoot, 'build', 'outputs', 'bundle', 'release', '*.aab'),
  ];

  for (const dir of [
    path.join(projectRoot, 'app', 'build', 'outputs', 'bundle', 'release'),
    path.join(projectRoot, 'build', 'outputs', 'bundle', 'release'),
  ]) {
    if (fs.existsSync(dir)) {
      const files = fs.readdirSync(dir).filter(f => f.endsWith('.aab'));
      if (files.length) return path.join(dir, files[0]);
    }
  }

  // Deep search fallback
  try {
    const { stdout } = await execAsync(`find "${projectRoot}" -name "*.aab" -path "*/release/*"`, { timeout: 10000 });
    const found = stdout.trim().split('\n').filter(Boolean);
    if (found.length) return found[0];
  } catch {}

  return null;
}

function findFile(dir, name) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isFile() && entry.name === name) return full;
    if (entry.isDirectory() && !entry.name.startsWith('.') && entry.name !== 'node_modules' && entry.name !== 'build') {
      const found = findFile(full, name);
      if (found) return found;
    }
  }
  return null;
}

// ── Cleanup old jobs (after 2 hours) ─────────────────────────────────────────
setInterval(() => {
  const now = Date.now();
  for (const [id, job] of jobs.entries()) {
    if (now - job.createdAt > 2 * 60 * 60 * 1000) {
      const workDir = path.join(BUILD_DIR, id);
      fs.rmSync(workDir, { recursive: true, force: true });
      jobs.delete(id);
    }
  }
}, 30 * 60 * 1000);

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`AAB Forge server running on http://localhost:${PORT}`);
  console.log(`Android SDK root: ${SDK_ROOT}`);
  console.log(`Build directory:  ${BUILD_DIR}`);
});
