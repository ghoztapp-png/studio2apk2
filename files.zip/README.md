# AAB Forge — Android App Bundle Builder

Upload a raw Android source ZIP → get back a signed `.aab` ready for Google Play.

---

## What it does

1. User uploads their Android project ZIP (Java/Kotlin + XML)
2. Fills in app name, ID, version, and keystore password
3. Server extracts the ZIP, patches `build.gradle` and `AndroidManifest.xml`
4. Generates a new signing keystore automatically using `keytool`
5. Runs `./gradlew bundleRelease` in the cloud
6. Returns a signed `.aab` file + the keystore for download

---

## Stack

| Layer | Tech |
|-------|------|
| Frontend | Plain HTML/CSS/JS (drop-in to any static host) |
| Backend | Node.js + Express |
| Build engine | Gradle (via `gradlew` in the uploaded project) |
| Signing | `keytool` (comes with JDK) |
| Containerization | Docker |

---

## Quickstart (Docker — recommended)

```bash
# 1. Clone / download this project
cd aab-builder

# 2. Build the Docker image
docker build -t aab-forge .

# 3. Run it
docker run -p 3001:3001 aab-forge
```

Open `http://localhost:3001` in your browser.

---

## Quickstart (without Docker)

### Prerequisites

You need these installed on the machine running the server:

| Tool | Version | Install |
|------|---------|---------|
| Node.js | 18+ | https://nodejs.org |
| Java JDK | 17+ | `apt install openjdk-17-jdk` or https://adoptium.net |
| Android SDK | — | See below |
| `unzip` | any | `apt install unzip` |

### Install Android SDK command-line tools (no Android Studio needed)

```bash
# Create SDK dir
mkdir -p /opt/android-sdk/cmdline-tools

# Download command-line tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-11076708_latest.zip -d /opt/android-sdk/cmdline-tools
mv /opt/android-sdk/cmdline-tools/cmdline-tools /opt/android-sdk/cmdline-tools/latest

# Add to PATH
export ANDROID_SDK_ROOT=/opt/android-sdk
export PATH="$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools:$PATH"

# Accept licenses and install required SDK components
yes | sdkmanager --licenses
sdkmanager "platform-tools" "build-tools;34.0.0" "platforms;android-34"
```

### Run the server

```bash
cd backend
npm install
ANDROID_SDK_ROOT=/opt/android-sdk node server.js
```

Open `http://localhost:3001`.

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `ANDROID_SDK_ROOT` | `/opt/android-sdk` | Path to Android SDK |
| `BUILD_DIR` | `/tmp/aab-forge-builds` | Where build workdirs are created |
| `PORT` | `3001` | HTTP port |

---

## Deploying to the cloud

### Fly.io (recommended — persistent disk for SDK)

```bash
fly launch
fly volumes create android_builds --size 20  # for SDK + build cache
fly deploy
```

### Railway / Render

Push the repo — both platforms support Docker. Set the env vars in their dashboard.

### VPS (DigitalOcean, Linode, etc.)

Install Docker, run the container with `--restart=always`. For production, put Nginx in front:

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    client_max_body_size 250M;

    location / {
        proxy_pass http://localhost:3001;
        proxy_read_timeout 600s;  # builds take a few minutes
    }
}
```

---

## Project ZIP requirements

Your ZIP must contain a valid Android Gradle project:

```
your-app.zip
├── settings.gradle          ← required
├── build.gradle             ← root build file
├── gradlew                  ← Gradle wrapper (REQUIRED)
├── gradlew.bat
├── gradle/
│   └── wrapper/
│       └── gradle-wrapper.properties
└── app/
    ├── build.gradle         ← app-level build file
    └── src/
        └── main/
            ├── AndroidManifest.xml
            ├── java/ (or kotlin/)
            └── res/
```

**Important:** The `gradlew` wrapper must be included. The server patches your `build.gradle` with the app ID, version, and signing config you provide — it does not replace your logic, only the metadata.

---

## Security notes

- Keystores are stored temporarily in `/tmp/aab-forge-builds/<jobId>/` and deleted after 2 hours
- For a production multi-user service, add authentication before the `/api/build` endpoint
- Consider encrypting keystores at rest if storing them longer-term
- Each build runs in its own isolated directory

---

## Limitations

- Builds that require NDK (native C/C++) need extra SDK components: add `ndk;26.1.10909125` to the `sdkmanager` install
- React Native / Expo projects need additional tooling — this tool targets raw Android (Java/Kotlin) projects
- Very large projects (>100MB source) may need the `MAX_ZIP_MB` limit raised in `server.js`
