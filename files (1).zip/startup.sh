#!/bin/bash
# startup.sh — runs on every Railway boot
# Installs Android SDK into the persistent volume on first run only

set -e

SDK_DIR="${ANDROID_SDK_ROOT:-/opt/android-sdk}"
TOOLS_DIR="$SDK_DIR/cmdline-tools/latest/bin"

echo "=== AAB Forge startup ==="

if [ ! -f "$TOOLS_DIR/sdkmanager" ]; then
  echo "Android SDK not found on volume — installing now (one-time, ~5 mins)..."
  mkdir -p "$SDK_DIR/cmdline-tools"

  wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O /tmp/cmdtools.zip
  unzip -q /tmp/cmdtools.zip -d "$SDK_DIR/cmdline-tools"
  mv "$SDK_DIR/cmdline-tools/cmdline-tools" "$SDK_DIR/cmdline-tools/latest"
  rm /tmp/cmdtools.zip

  export PATH="$TOOLS_DIR:$SDK_DIR/platform-tools:$PATH"

  yes | sdkmanager --licenses > /dev/null 2>&1 || true
  sdkmanager \
    "platform-tools" \
    "build-tools;34.0.0" \
    "platforms;android-34" \
    "platforms;android-33" \
    "platforms;android-30"

  echo "Android SDK installed successfully."
else
  echo "Android SDK already installed — skipping."
fi

export PATH="$TOOLS_DIR:$SDK_DIR/platform-tools:$SDK_DIR/build-tools/34.0.0:$PATH"

echo "Starting AAB Forge server on port ${PORT:-3001}..."
exec node /app/backend/server.js
